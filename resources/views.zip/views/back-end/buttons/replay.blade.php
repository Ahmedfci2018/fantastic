<a href="{{route($module_name_plural.'.edit', $row)}}" rel="tooltip" title="" class="btn btn-white btn-link btn-sm" data-original-title="@lang('site.edit') @lang('site.'.$module_name_singular)">
    <i class="material-icons">replay</i>
</a>
