<footer class="footer">
    <div class="container-fluid">
        <nav class="float-left">
            <ul>
                <li>
                    <a href="https://www.creative-tim.com">
                        Creative Tim
                    </a>
                </li>
            </ul>
        </nav>
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
{{--
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> for a better web.
--}}
        </div>
        <!-- your footer here -->
    </div>
</footer>
