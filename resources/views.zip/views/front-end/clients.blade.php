@extends('layouts.app')

@section('title') Clients Architecticts @endsection
{{-- @section('keywords') Planning Facade design Landscape design Architectural design @endsection
@section('description') Planning Facade design Landscape design Architectural design @endsection --}}
@section('content')
    <!-- breadcrumb start-->
    <section class="breadcrumb breadcrumb_bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb_iner text-center">
                        <div class="breadcrumb_iner_item">
                            <h1>Clients Architecticts</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb start-->

    <!-- service part start-->
    <section class="project_part padding_bottom">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-4">
                    <div class="section_tittle">
                        <h2>Our clients</h2>
                    </div>
                </div>
            </div>
            <div class="container">
                <section class="customer-logos slider">
                    @foreach($rows as $row)
                        <div class="slide">
                            <div class="single_project_tittle" style="padding: 5px;">{{$row->name}}</div>
                            <img alt="{{$row->name}}" src="{{asset('uploads/client_images/'. $row->image)}}"> <p style="padding: 5px;">{{$row->description}}</p>
                        </div>
                    @endforeach
                </section>
            </div>
        </div>
    </section>
    <!-- service part end-->

@endsection
