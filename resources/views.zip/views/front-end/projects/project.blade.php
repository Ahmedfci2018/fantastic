@extends('layouts.app')

@section('title') {{$project->title}} @endsection
@section('content')

    <!-- breadcrumb start-->
    <section class="breadcrumb breadcrumb_bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb_iner text-center">
                        <div class="breadcrumb_iner_item">
                            <h1>{{$project->title}}</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb start-->

    <!-- project_details start-->
    <section class="project_details section_padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="project_details_img">
                        <img src="{{ asset('uploads/project_images/'. $project->image)}}" alt="{{$project->description}}">
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="project_details_text">
                        <h2>Project Description</h2>
                        <p>{{$project->description}} </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="project_details_sidebar">
                        <h4>Client details</h4>
                        <p><i class="ti-user"></i>Client: <span>{{$project->client->name}}</span> </p>
                        <p><i class="ti-archive"></i>Category: <span>{{$project->category->name}}</span> </p>
                        <p><i class="ti-calendar"></i>Starts on:: <span>{{$project->startsOn}}</span> </p>
                        <p><i class="ti-calendar"></i>Ends on: <span>{{$project->endsOn}}</span> </p>
                        <p><i class="ti-location-pin"></i>Location: <span>{{$project->country}}</span> </p>
                        <p><i class="ti-user"></i>Architect: <span>{{$project->architect}}</span> </p>
                        <p><i class="ti-link"></i>Link: <span><a style="color: blue" target="_blank" href="{{$project->link}}">open link</a></span> </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- project_details end-->

    <!-- project details gallery start-->
    <section class="project_gallery padding_bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>gallery</h2>
                    <div class="grid gallery">
                        <div class="grid-sizer"></div>

                        @foreach($project->images as $index=>$image)
                            <div class="grid-item {{$index == 0 ? 'big_weight' :''}}">
                                <a href="{{asset('uploads/project_images/'. $image->image)}}" class="">
                                    <div class="project_img">
                                        <img src="{{asset('uploads/project_images/'. $image->image)}}" alt="">
                                    </div>
                                </a>
                            </div>
                        @endforeach
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- project details gallery start-->
@endsection

@push('script')
<script>
window.onload = function() {
    if(!window.location.hash) {
        window.location = window.location + '#loaded';
        window.location.reload();
    }
}
</script>
@endpush
