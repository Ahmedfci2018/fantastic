@extends('layouts.app')

@push('style')
    {{-- .slick-track{
        width
    } --}}

    <style>
        .thumbnails{
            margin-left: 80px;
        }
    </style>
@endpush
@section('title') Services Architecticts @endsection
@section('content')
    <!-- breadcrumb start-->
    <section class="breadcrumb breadcrumb_bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb_iner text-center">
                        <div class="breadcrumb_iner_item">
                            <h2>Services</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb start-->

    <!-- service part start-->
    <section class="project_part padding_bottom">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-4">
                    <div class="section_tittle">
                        <h2>Our Services</h2>
                    </div>
                </div>
            </div>
            <div class="carousel slide" id="myCarousel">
                <div class="carousel-inner">
                    <?php $index=0 ?>
                    @for ($j = 0; $j < count($rows)/3; $j++)

                        <div class="item {{$j==0 ? 'active': ''}}">
                            <ul class="thumbnails">
                                @for ($i = 0; $i < 3; $i++)

                                <li class="span3">
                                    <div class="thumbnail">
                                        <a title="{{$rows[$index]->name}}" href="#"><img alt="{{$rows[$index]->name}}" style="width: 100%;height: 150px" src="{{asset('uploads/service_images/'. $rows[$index]->image)}}" alt=""></a>
                                    </div>
                                    <div class="caption">
                                        <h4 style="margin-top:23px;">{{$rows[$index]->name}}</h4>
                                        <p>{{$rows[$index]->description}}</p>
                                    </div>
                                </li>
                                <?php $index++;
                                if ($index == count($rows)) {
                                break;
                                }
                                ?>
                                @endfor
                            </ul>
                        </div><!-- /Slide1 -->

                    @endfor

                </div>

                <div class="control-box">
                    <a data-slide="prev" href="#myCarousel" class="carousel-control left">‹</a>
                    <a data-slide="next" href="#myCarousel" class="carousel-control right">›</a>
                </div><!-- /.control-box -->

            </div><!-- /#myCarousel -->
        </div>
    </section>
    <!-- service part end-->

@endsection

@push('script')
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/2.3.1/js/bootstrap.min.js'></script><script  src="./script.js"></script>

<script>
    // Carousel Auto-Cycle
  $(document).ready(function() {
    $('.carousel').carousel({
      interval: 6000
    })
  });
</script>
@endpush
