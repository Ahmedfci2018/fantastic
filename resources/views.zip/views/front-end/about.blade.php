@extends('layouts.app')
@section('title') Makram Architecticts @endsection
@section('content')
    <!-- breadcrumb start-->
    <section class="breadcrumb breadcrumb_bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb_iner text-center">
                        <div class="breadcrumb_iner_item">
                            <h2>about us</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- breadcrumb start-->

    <!-- home tips start-->
    <section class="home_tips padding_top">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="home_tips_text text-center">
                        <h1>About Makram architects</h1>
                        <p>MAKRAM ARCHITECTS is an architectural firm established in Egypt on 2002 by Dr. Eng. Saad Makram, offering many architectural services including:
                            Planning, Architectural design, Interior Design, Landscape, Working Details, Bills of Quantities and Presentation.
                            <br>
                            The range of services we offer encompasses many types of buildings such as
                        </p>
                    </div>
                    <div class="home_tips_video_popup">
                        <video width="710" height="400" controls>
                            <source src="{{asset('img/makram.mp4')}}" type=video/mp4>
                        </video>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- home tips start-->

    <div class="overlay_section">

    </div>

    <!-- single special page item start -->
    <section class="single_page_special">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_page_special_item owl-carousel">
                        <div class="single_slide_item">
                            <img src="{{asset("img/icon/007-house.svg")}}" alt="Facade design">
                            <div class="single_special_text">
                                <h3>Residential:</h3>
                                <p>Apartment Buildings and Complexes, Private Residences, Housing Compounds.
                                </p>
                            </div>
                        </div>
                        <div class="single_slide_item">
                            <img src="{{asset("img/icon/013-project.svg")}}" alt="Architectural firm">
                            <div class="single_special_text">
                                <h3>Commercial:</h3>
                                <p>Office Buildings and Complexes, Commercial Centers, Shopping Malls & Hypermarkets, etc.
                                </p>
                            </div>
                        </div>
                        <div class="single_slide_item">
                            <img src="{{asset("img/icon/033-brickwall-1.svg")}}" alt="Egyptian architects">
                            <div class="single_special_text">
                                <h3>Hospitality: </h3>
                                <p>Hotels, Motels, Hotel Resorts, Sports Clubs, Recreational Centers.
                                </p>
                            </div>
                        </div>
                        <div class="single_slide_item">
                            <img src="{{asset("img/icon/041-measuring-tape.svg")}}" alt="Urban design">
                            <div class="single_special_text">
                                <h3>Health Care:</h3>
                                <p>Hospitals, Medical Clinics.</p>
                            </div>
                        </div>
                        <div class="single_slide_item">
                            <img src="{{asset("img/icon/011-architecture-and-city.svg")}}" alt="Interior design">
                            <div class="single_special_text">
                                <h3>Institutional:</h3>
                                <p>Specialized Colleges, Schools, Technical Schools.</p>
                            </div>
                        </div>
                        <div class="single_slide_item">
                            <img src="{{asset("img/icon/009-blueprint-1.svg")}}" alt="Decoration">
                            <div class="single_special_text">
                                <h3>Industrial:</h3>
                                <p>Plants.</p>
                            </div>
                        </div>
                        <div class="single_slide_item">
                            <img src="{{asset("img/icon/004-home.svg")}}" alt="Landscape design">
                            <div class="single_special_text">
                                <h3>Religious buildings:</h3>
                                <p>cathedral, churches, mosques.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <p class="text-center">We believe that The Architectural experience in diverse fields is the result of hard work, innovation and research, <br>
                that ensure meeting client requirements and create a <b>PERFECTLY STUCTURED ART</b></p>
        </div>
    </section>
    <!-- single special page item end -->
    <!-- project_part part start-->
     <!-- <section class="project_part padding_bottom">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-4">
                    <div class="section_tittle">
                        <h2>Our team</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="project_slider owl-carousel">
                        <div class="single_project_slide">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <img src="{{asset("img/project/project_1.png")}}" alt="#">
                                    <div class="single_project_text">
                                        <img src="{{asset("img/client/client_2.png")}}" class="client_img" alt="">
                                        <a href="#" class="admin_name">Saad makram</a>
                                        <span>Project maneger</span>
                                        <p>Lorem ipsum dolor sit amet lorem consectetur adipiscing look. </p>
                                        <a href="all_project.html" class="btn_1">learn more <span><img
                                                        src="{{asset("img/icon/left.svg")}}" alt=""></span> </a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <img src="{{asset("img/project/project_2.png")}}" alt="#">
                                    <div class="single_project_text">
                                        <img src="{{asset("img/client/client_3.png")}}" class="client_img" alt="">
                                        <a href="#" class="admin_name">Saad makram</a>
                                        <span>Project maneger</span>
                                        <p>Lorem ipsum dolor sit amet lorem consectetur adipiscing look. </p>
                                        <a href="all_project.html" class="btn_1">learn more <span><img
                                                        src="{{asset("img/icon/left.svg")}}" alt=""></span> </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="single_project_slide">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <img src="{{asset("img/project/project_1.png")}}" alt="#">
                                    <div class="single_project_text">
                                        <img src="{{asset("img/client/client_2.png")}}" class="client_img" alt="">
                                        <a href="#" class="admin_name">Saad makram</a>
                                        <span>Project maneger</span>
                                        <p>Lorem ipsum dolor sit amet lorem consectetur adipiscing look. </p>
                                        <a href="all_project.html" class="btn_1">learn more <span><img
                                                        src="{{asset("img/icon/left.svg")}}" alt=""></span> </a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <img src="{{asset("img/project/project_2.png")}}" alt="#">
                                    <div class="single_project_text">
                                        <img src="{{asset("img/client/client_3.png")}}" class="client_img" alt="">
                                        <a href="#" class="admin_name">Saad makram</a>
                                        <span>Project maneger</span>
                                        <p>Lorem ipsum dolor sit amet lorem consectetur adipiscing look. </p>
                                        <a href="all_project.html" class="btn_1">learn more <span><img
                                                        src="{{asset("img/icon/left.svg")}}" alt=""></span> </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- project_part part end-->
@endsection
