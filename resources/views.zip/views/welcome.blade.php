@extends('layouts.app')
@push('style')
<style>
    .thumbnails{
        margin-left: 80px;
    }
</style>
@endpush

@section('title') Makram Architecticts @endsection
@section('content')

<!-- banner part start-->
<section class="banner_part">
    <!-- slider -->
       <div class="span12">

         <div id="sequence-theme">
           <div id="sequence">
             <img class="prev" src="/img/slides/bt-prev.png" alt="Previous Frame" />
             <img class="next" src="/img/slides/bt-next.png" alt="Next Frame" />
             <ul>
                 @foreach ($sliders as $index=>$item)
                    <li class="{{$index==0 ? 'animate-in' : ''}}">
                        <h2 class="title">{{$item->title}}</h2>
                        <h5 class="subtitle">{{$item->description}}</h5>
                        <img class="model" src="{{asset("uploads/slider_images/".$item->image)}}" alt="{{$item->title}}" />
                    </li>
                 @endforeach

             </ul>
           </div>
           <ul class="nav">
               @foreach ($sliders as $item)
                    <li><img src="{{asset("uploads/slider_images/".$item->image)}}" style="width:72px" alt="Thumbnail" /></li>
               @endforeach

           </ul>
         </div>

       </div>
       <!-- end slider -->
</section> <!-- banner part start-->
    <!-- banner part start-->
    <!-- banner part start-->
    <div class="our_speciality">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_special_part border_left">
                        <i class="fa fa-magic" ></i>
                        <div class="single_special_text">
                            <h3>Innovation:</h3>
                            <p>We are always keen at the beginning of each project to come up with an innovative idea that guarantees each project enough of excellence and uniqueness.</p>
                        </div>
                    </div>
                    <div class="single_special_part border_left">
                        <i class="fa fa-cubes" ></i>
                        <div class="single_special_text">
                            <h3>Function:</h3>
                            <p>Ensuring that the project achieves the required function and enable sought users to carry out their tasks efficiently, is a major and permanent goal for us to ensure that we carry out all the necessary studies at all stages of design. </p>
                        </div>
                    </div>
                    <div class="single_special_part border_left">
                        <i class="fa fa-paint-brush" ></i>
                        <div class="single_special_text">
                            <h3>Economy:</h3>
                            <p>Not only to achieve functional efficiency and to achieve design to the maximum degree of creativity and uniqueness, but also at the lowest cost and rationalizing the cost required to implement any project.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- banner part start-->

    <!-- about part start-->
    <a name="about_us"></a>  <div class="about_part section_bg">
        <div class="container-fluid">
            <div class="row justify-content-end">
                <div class="col-lg-4 col-md-6">
                    <div class="about_part_text">
                        <h2>About Us</h2>
                        <p>MAKRAM is an architectural firm established in Mansoura, Egypt on 2001by Dr. Saad Makram offering many architectural services including:
                            Planning, Architectural design, Interior Design, Landscape, Working Details, Bills of Quantities and Presentation.
                        </p>
                        <p>We believe that The Architectural experience in diverse fields is the result of hard work, research, that ensure meeting client requirements.</p>
                        <a href="{{route('front.about')}}" class="btn_1">learn more <span><img src="{{asset("img/icon/left.svg")}}" alt="Architectural design, Interior Design"></span> </a>
                    </div>
                </div>
                <div class="col-lg-7 col-md-6">
                    <div class="about_img">
                        <img src="{{asset("img/about_overlay.png")}}" alt="Architectural consultant">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- about part end-->


     <!-- service part start-->
     <section style="top: 98px;
     position: relative;" class="project_part padding_bottom">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-4">
                    <div class="section_tittle">
                        <h2>Our Services</h2>
                    </div>
                </div>
            </div>
            <div class="carousel slide" id="myCarousel">
                <div class="carousel-inner">
                    <?php $index=0 ?>
                    @for ($j = 0; $j < count($services)/3; $j++)

                        <div class="item {{$j==0 ? 'active': ''}}">
                            <ul class="thumbnails">
                                @for ($i = 0; $i < 3; $i++)

                                <li class="span3">
                                    <div class="thumbnail">
                                        <a href="#" title="{{$services[$index]->name}}"><img style="width: 100%;height: 150px" src="{{asset('uploads/service_images/'. $services[$index]->image)}}" alt="{{$services[$index]->name}}"></a>
                                    </div>
                                    <div class="caption">
                                        <h4 style="margin-top:23px;">{{$services[$index]->name}}</h4>
                                        <p>{{$services[$index]->description}}</p>
                                    </div>
                                </li>
                                <?php $index++;
                                if ($index == count($services)) {
                                break;
                                }
                                ?>
                                @endfor
                            </ul>
                        </div><!-- /Slide1 -->

                    @endfor

                </div>

                <div class="control-box">
                    <a data-slide="prev" href="#myCarousel" class="carousel-control left">‹</a>
                    <a data-slide="next" href="#myCarousel" class="carousel-control right">›</a>
                </div><!-- /.control-box -->

            </div><!-- /#myCarousel -->
        </div>
    </section>
    <!-- service part end-->

    @if(count($news)>0)
    <!-- blog part start-->
    <section class="blog_part">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-7">
                    <div class="section_tittle">
                        <h2>Latest News</h2>
                        <p>The range of services we offer encompasses many types of buildings here is our latest projects</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="blog_post_slider owl-carousel">
                        @foreach($news as $new)
                            <div class="single_blog_post">
                                <div class="row">
                                    <div class="col-lg-7">
                                        <div class="single_img">
                                            <a href="#" title="{{$new->name}}"><img src="{{asset("uploads/news_images/".$new->image)}}" alt="{{$new->name}}"></a>

                                        </div>
                                    </div>
                                    <div class="col-lg-7">
                                        <div class="single_project_text">
                                            <div class="single_project_tittle">
                                                <h4> <a target="_blank" title="{{$new->name}}" href="{{$new->link}}">{{$new->name}}</a></h4>
                                                <p>{{$new->title}}</p>
                                                <span>{{$new->date}}</span>
                                            </div>
                                            <p>{{$new->description}}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="slider-counter"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- blog part end-->
    @endif
@endsection
@push('script')
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/2.3.1/js/bootstrap.min.js'></script><script  src="./script.js"></script>

<script>
    // Carousel Auto-Cycle
  $(document).ready(function() {
    $('.carousel').carousel({
      interval: 6000
    })
  });
</script>
@endpush
