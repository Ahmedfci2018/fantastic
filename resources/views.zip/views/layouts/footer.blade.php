
<!-- footer part start-->
<footer class="footer-area" id="about-us">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-3 col-sm-6">
                <div class="single-footer-widget footer_1">
                    <h4>About Us</h4>
                    <p>MAKRAM is an architectural firm established in Mansoura, Egypt on 2001by Dr. Saad Makram offering many architectural services including:
                        Planning, Architectural design, Interior Design, Landscape, Working Details, Bills of Quantities and Presentation.
                    </p>
                    <div class="social_icon">
                        <a href="https://www.facebook.com/makramarchitects/"><i class="ti-facebook"></i></a>
                        <a href="https://www.youtube.com/channel/UCq95TGQt6xiY36yKoRh_wbw"><i class="ti-youtube"></i></a>
                        <a href="https://www.instagram.com/"><i class="ti-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-sm-6">
                <div class="single-footer-widget footer_2">
                    <h4>Projects</h4>
                    <ul>
                        <li><a href="#" title="Residential">Residential</a></li>
                        <li><a href="#" title="Commercial"> Commercial</a></li>
                        <li><a href="#" title="Architectural design">Recently Completed</a></li>
                        <li><a href="#" title="architectural firm"> Under Construction</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single-footer-widget footer_2">
                    <h4>Contact us</h4>
                    <div class="contact_info">
                        <p><span>Address :</span> Um Kolthoum Street, Talkha, Ad Daqahliyah, Egypt </p>
                        <p><span>Phone :</span> +2 0100 120 4484 </p>
                        <p><span>Email :</span> saad_makram@yahoo.com </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6">
                <div class="single-footer-widget footer_3">
                    <h4>Newsletter</h4>
                    <p>Sign up with your email address to receive news and updates.

                    </p>
                    <div class="form-wrap" id="mc_embed_signup">
                        <form target="_blank"
                              action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
                              method="get" class="form-inline">
                            <input class="form-control" name="EMAIL" placeholder="Your Email Address"
                                   onfocus="this.placeholder = ''" onBlur="this.placeholder = 'Your Email Address '"
                                   required="" type="email">
                            <button class="btn btn-default text-uppercase"><i
                                        class="far fa-paper-plane"></i></button>
                            <div style="position: absolute; left: -5000px;">
                                <input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value=""
                                       type="text">
                            </div>

                            <div class="info"></div>
                        </form>
                    </div>

                    <div id="fb-root"></div>
                    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v4.0&appId=415789419242682&autoLogAppEvents=1"></script>

                    <div class="fb-page"
                         data-href="https://www.facebook.com/makramarchitects/"
                         data-width="380"
                         data-hide-cover="false"
                         data-show-facepile="false"></div>

                </div>
            </div>
        </div>
    </div>
    <div class="copyright_part">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | designed & developed by <a href="http://www.smartsolutions-eg.com" target="_blank">Smart solutions</a>
                        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer part end-->
