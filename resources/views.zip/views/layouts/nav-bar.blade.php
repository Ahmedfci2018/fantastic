<!--::header part start::-->
<header class="main_menu home_menu">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12">
                <div class="main_menu_iner">
                    <div class="search_icon">
                        <a id="search_1" href="javascript:void(0)"><i class="ti-search"></i></a>
                    </div>
                    <div class="logo">
                        <a title="Architecture" href="{{url('/')}}"><img src="{{asset("img/logo.png")}}" alt="Egyptian architects"></a>
                    </div>
                    <span class="menu-trigger visible-xs">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    <div class="off-canven-menu">
                            <span class="close-icon">
                                <i class="ti-close"></i>
                            </span>
                        <div class="canven-menu-warp">
                            <div class="canven-menu-iner">
                                <ul>
                                    <li><a title="Architecture" href="{{url('/')}}">Home</a></li>
                                    <li><a title="About Makram" href="{{route('front.about')}}">About</a></li>
                                    <li><a title="Services Architecture" href="{{route('front.services')}}">Services</a></li>
                                    <li class="btn btn-primary dropdown-toggle" type="text" data-toggle="dropdown">Projects
                                        </li>
                                    <ul class="dropdown-menu">
                                        @foreach($categories as $category)
                                        <li><a title="{{$category->name}}" href="{{route('front.all_project',$category->id)}}">{{$category->name}}</a></li>
                                        @endforeach
                                    </ul>
                                    <li><a title="Architecture Clients" href="{{route('front.clients')}}">Clients</a></li>
                                    <li><a title="Makram Architecture" href="#contacts">Contacts</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="search_input" id="search_input_box">
        <div class="container">
            <form class="d-flex justify-content-between search-inner">
                <input type="text" class="form-control" id="search_input" placeholder="Search Here">
                <button type="submit" class="btn"></button>
                <span class="ti-close" id="close_search" title="Close Search"></span>
            </form>
        </div>
    </div>
</header>
<!-- Header part end-->
