<!doctype html>
<html lang="en">

<head>
<meta name="google-site-verification" content="FVs03OvnYny_NU2IbhLnnAAYVTFUGnB0q30M-o8xnp0" />
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>@yield('title')</title>
    <link rel="icon" href="img/favicon.png">

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta content="Architecture Architect Architectural firm Architectural consultant Architectural design Urban design Interior design Construction Egyptian architects Decoration Planning Facade design " name="description"/>
    <meta content="Architecture Architect Architectural firm Architectural consultant Architectural design Urban design Interior design Construction Egyptian architects Decoration Planning Facade design " name="keywords" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{asset("css/bootstrap.min.css")}}">
    <!-- animate CSS -->
    <link rel="stylesheet" href="{{asset("css/animate.css")}}">
    <!-- owl carousel CSS -->
    <link rel="stylesheet" href="{{asset("css/owl.carousel.min.css")}}">
    <!-- themify CSS -->
    <link rel="stylesheet" href="{{asset("css/themify-icons.css")}}">
    <!-- flaticon CSS -->
    <link rel="stylesheet" href="{{asset("css/flaticon.css")}}">
    <!-- font awesome CSS -->
    <link rel="stylesheet" href="{{asset("css/magnific-popup.css")}}">
    <!-- swiper CSS -->
    <link rel="stylesheet" href="{{asset("css/slick.css")}}">
    <link rel="stylesheet" href="{{asset("css/gijgo.min.css")}}">
    <link rel="stylesheet" href="{{asset("css/nice-select.css")}}">
    <link rel="stylesheet" href="{{asset("css/all.css")}}">
    <!-- style CSS -->
    <link rel="stylesheet" href="{{asset("css/style.css")}}">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <link rel="stylesheet" href="/css-banner/bootstrap.css" />
    <link rel="stylesheet" href="/css-banner/bootstrap-responsive.css" />
    <link rel="stylesheet" href="/css-banner/prettyPhoto.css" />
    <link rel="stylesheet" href="/css-banner/sequence.css" />
    <link rel="stylesheet" href="/css-banner/style.css" />

    {{--noty--}}
    <link rel="stylesheet" href="/assets/plugins/noty/noty.css">
    <script src="/assets/plugins/noty/noty.min.js"></script>
    @stack('style')

    <script>

//prevent menu
 document.addEventListener('contextmenu',  event => event.preventDefault());
        //   $(document).on('contextmenu', 'img', function() {
        //     alert();
        //       return false;
        //   });

        </script>

    {{-- <script>

        $('.about_img').click(function (e) {
            alert('ggggdd');
      if(e.button == 2) { // right click
        return false; // do nothing!
      }
        });

    </script> --}}
    {{-- <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script> --}}

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-174502442-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-174502442-1');
</script>

</head>


<body>
<!-- Navbar -->
@include('layouts.nav-bar')
<!-- End Navbar -->
<div>

    @yield('content')
    @include('partials._session')
    @include('layouts.contact')
    @include('layouts.footer')
</div>
<!-- jquery plugins here-->
<!-- jquery -->
<script src="/js/jquery-1.12.1.min.js"></script>
    <!-- popper js -->
    <script src="/js/popper.min.js"></script>
    <!-- bootstrap js -->
    <script src="/js/bootstrap.min.js"></script>
    <!-- easing js -->
    <script src="/js/jquery.magnific-popup.js"></script>
    <!-- swiper js -->
    <script src="/js/swiper.min.js"></script>
    <!-- swiper js -->
    <script src="/js/masonry.pkgd.js"></script>
    <!-- particles js -->
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/gmap3.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=&callback=initMap">
    </script>
    <!-- slick js -->
    <script src="/js/slick.min.js"></script>
    <script src="/js/gijgo.min.js"></script>
    <script src="/js/jquery.nice-select.min.js"></script>
    <!-- contact js -->
    <script src="/js/jquery.ajaxchimp.min.js"></script>
    <script src="/js/jquery.form.js"></script>
    <script src="/js/jquery.validate.min.js"></script>
    <script src="/js/mail-script.js"></script>
    <script src="/js/contact.js"></script>
    <!-- custom js -->
    <script src="/js/custom.js"></script>
    <script src="/js/script.js"></script>
     <!-- Javascript Libraries -->
  <script src="/js-banner/sequence.jquery.js"></script>

  <!-- Template Custom Javascript File -->
  <script src="/js-banner/custom.js"></script>
<!--  Notifications Plugin    -->
<script src="/assets/js/plugins/bootstrap-notify.js"></script>
<script>

    var myIndex = 0;
    carousel();

    function carousel() {
        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        myIndex++;
        if (myIndex > x.length) {myIndex = 1}
        x[myIndex-1].style.display = "block";
        setTimeout(carousel, 3000); // Change image every 2 seconds
    }
</script>

@stack('script')
</body>

</html>

